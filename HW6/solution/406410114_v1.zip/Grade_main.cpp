#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;

char LetterGrade( double grade ){
    if( grade>=90 && grade<100)
        return 'A';
    else if( grade>=80 && grade<90)
        return 'B';
    else if( grade>=70 && grade<80)
        return 'C';
    else if( grade>=60 && grade<70)
        return 'D';
    return 'F';
    
}//LetterGrade


int main() {
    
    //read input
    string input_file,output_file;
    cout << "Please enter the name of the input file."<<endl;
    cout << "Filename: ";
    cin >> input_file;
    cout << input_file<<endl;
    ifstream fin(input_file);
    if(!fin) {
       cout << "Error! opening file isn't exist!\n";
       exit(0);
    }//if
    
    //process

    int n,t_case = 1;
    char c;
    fin >> n ;
    fin.get(c);// \n
    //cout << "n:"<<n<<endl;
    vector<English> Eng;
    vector<History> His;
    vector<Math> Mat;
    while ( n-- ){
        //cout << "input: "<<t_case++<<endl;
        string l_name,f_name,course;
        char line[1024]; 
        fin.getline(line,1024) ;


        string line_str;
        line_str.assign( line );
        //cout <<line_str<<endl;
        int current = 0;
        int pos = line_str.find_first_of(",", current);
        l_name = line_str.substr(current, pos - current);
        f_name =  line_str.substr(pos - current+2,line_str.length());
        
        fin >> course;
        cout << l_name<< "," << f_name<<","<<course<<endl;
        if( course ==  "English" ){
            int Att,Pro,Mid,Fin;
            fin >> Att>>Pro>>Mid>>Fin;
            English temp( l_name,f_name,course,Att,Pro,Mid,Fin );
            Eng.push_back(temp);
            //cout << Att<< "," << Pro<<","<<Mid<<","<<Fin<<endl;
        }//if
        else if( course ==  "History" ){
            int Term,Mid,Fin;
            fin >> Term>>Mid>>Fin;
            History temp( l_name,f_name,course,Term,Mid,Fin );
            His.push_back(temp);
            //cout << Term<< "," << Mid<<","<<Fin<<endl;
        }//else if
        
        else if ( course ==  "Math"){
            int Q1,Q2,Q3,Q4,Q5,T1,T2,Fin;
            fin >>Q1>>Q2>>Q3>>Q4>>Q5>>T1>>T2>>Fin;
            Math temp( l_name,f_name,course,Q1,Q2,Q3,Q4,Q5,T1,T2,Fin );
            Mat.push_back(temp);
            //cout << Q1<< "," << Q2<<","<<Q3<<","<<Q4<<","<<Q5<<","<<T1<<","<<T2<<","<<Fin<<endl;
        }//else if
        
        fin.get(c);// \n
    }//while
        
        
    fin.close();
    
    
    
    //output
    cout << "Please enter the name of the output file."<<endl;
    cout << "Filename: ";
    cin >> output_file;
    
    
    //fout
    ofstream fout(output_file); 
    
    
    
    if(!fout) { 
        cout << "�L�k�g�J�ɮ�" <<endl ;
        return 1; 
    } //if
    
    
    fout << "Student Grade Summary\n";
    fout << "----------------------------------\n\n";
    fout << "ENGLISH CLASS\n\n";
    fout << left << setw(36) << "Student" << left << setw(18) << "Final" <<  left << setw(18) << "Final" <<  left << "Letter"<< endl;
    fout << left << setw(36) << "Name"    << left << setw(18) << "Exam"  <<  left << setw(18)  << "Avg"  <<  left << "Grade" << endl;
    fout << "--------------------------------------------------------------------------------"<<endl;
    for ( int i = 0;i< Eng.size();i++ ){
        char letgrade = LetterGrade(Eng[i].get_gra());
        fout << left << setw(36) << Eng[i].get_fir_name() + " " + Eng[i].get_la_name() << left << setw(18) << Eng[i].get_Final();
        fout << fixed << setprecision(2)<<  left << setw(18) << Eng[i].get_gra() << left << letgrade<< endl;
    }//for
    fout <<"\n";
    
    fout << "HISTORY CLASS\n\n";
    fout << left << setw(36) << "Student" << left << setw(18) << "Final" <<  left << setw(18) << "Final" <<  left << "Letter"<< endl;
    fout << left << setw(36) << "Name"    << left << setw(18) << "Exam"  <<  left << setw(18)  << "Avg"  <<  left << "Grade" << endl;
    fout << "--------------------------------------------------------------------------------"<<endl;
    for ( int i = 0;i< Eng.size();i++ ){
        char letgrade = LetterGrade(His[i].get_gra());
        fout << left << setw(36) << His[i].get_fir_name() + " " + His[i].get_la_name() << left << setw(18) << His[i].get_Final();
        fout << fixed << setprecision(2)<<  left << setw(18) << His[i].get_gra() << left << letgrade<< endl;
    }//for
    fout <<"\n";
    
    fout << "MATH CLASS\n\n";
    fout << left << setw(36) << "Student" << left << setw(18) << "Final" <<  left << setw(18) << "Final" <<  left << "Letter"<< endl;
    fout << left << setw(36) << "Name"    << left << setw(18) << "Exam"  <<  left << setw(18)  << "Avg"  <<  left << "Grade" << endl;
    fout << "--------------------------------------------------------------------------------"<<endl;
    for ( int i = 0;i< Eng.size();i++ ){
        char letgrade = LetterGrade(Mat[i].get_gra());
        fout << left << setw(36) << Mat[i].get_fir_name() + " " + Mat[i].get_la_name() << left << setw(18) << Mat[i].get_Final();
        fout << fixed << setprecision(2)<<  left << setw(18) << Mat[i].get_gra() << left << letgrade<< endl;
    }//for
    
    
    fout.close(); 
    cout << "Processing Complete."<<endl;
    
    
    
    
    return 0;
}//main