#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;

int const Math::get_Final() const{ return _Final;}