#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;

string const Student::get_course() const{ return _course;}