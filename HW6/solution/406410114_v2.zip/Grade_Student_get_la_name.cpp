#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;

string const Student::get_la_name() const{ return _la_name;}