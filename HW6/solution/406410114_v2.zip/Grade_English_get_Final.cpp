#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;

int const English::get_Final() const{ return _Final;}