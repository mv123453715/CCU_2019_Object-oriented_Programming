#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;

string const Student::get_fir_name() const{ return _fir_name;}