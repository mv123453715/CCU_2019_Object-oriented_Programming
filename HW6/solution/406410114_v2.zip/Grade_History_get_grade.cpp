#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;

double History::get_gra() { 
   grade();
   return _gra;
}//grade
            