#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;

double English::get_gra() { 
   grade();
   return _gra;
}//grade
            