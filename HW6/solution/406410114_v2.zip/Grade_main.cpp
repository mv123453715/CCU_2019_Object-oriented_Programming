#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;




int main() {
    vector<English> Eng;
    vector<History> His;
    vector<Math> Mat;
    test_input( Eng,His,Mat );
    test_output( Eng,His,Mat );
    return 0;
}//main