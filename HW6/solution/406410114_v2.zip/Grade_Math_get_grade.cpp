#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;

double Math::get_gra() { 
   grade();
   return _gra;
}//grade
            