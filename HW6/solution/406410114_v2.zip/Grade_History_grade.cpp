#include <bits/stdc++.h>
#include "Grade.h"
using namespace std;

const void History::grade(){
            _gra = double( _Term ) *0.25 +  double( _Mid) *0.35 + double( _Final) *0.4;
        }//grade