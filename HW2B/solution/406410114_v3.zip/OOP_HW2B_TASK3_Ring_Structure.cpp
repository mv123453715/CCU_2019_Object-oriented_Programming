#include <bits/stdc++.h>
using namespace std;

//class RingNode
class RingNode { 
    public:
      char value;// value stored in the node
      RingNode* next;// pointer to the next RingNode
};

//print_the_ring
void print_the_ring(const RingNode* head, int size) {
    for (int i=0; i<size; i++) {
      cout << head->value << endl;
      head = head->next;
    }//for
}//print_the_ring

//read_recursively
int read_recursively (fstream& file, RingNode*& current,RingNode*& head,int &size){
     char c; 
     if ( !file.eof() ){
         file.get(c);
         
         //if c is \0  file.close() and  current->next = head ,so we can get RingNode
         if ( c == '\0' ){ 
            file.close();
            current->next = head;
            current = head;
            return size; 
         }//if
         
         //if c is not  \0 and current == NULL,current value is c and pointer current store to head;
         //recursively call create RingNode
         else if ( current == NULL ){ 
             current = new RingNode();
             current ->value= c;
             head = current;
             size++;
             read_recursively (file, current,head,size);
         }//else if
         
         //if c is not  \0 and current != NULL,create new RingNode() 
         //recursively call create RingNode
         else {
             RingNode* ptr1 = new RingNode();
             ptr1->value = c;
             current->next = ptr1;
             current = current->next;
             size++;
             read_recursively (file, current,head,size);
             return size;    
         }//else
     }//if
}//read_recursively



int read_Input_to_RingNode(char filename[], RingNode*& current){
    //open file
    fstream  file; 
    file.open (filename , ios::in);
    //error handle
    if (!file) {
         cout << "Error! opening file isn't exist!\n";
         exit(0);
    }//if
    
    //initialization 
    int size = 0;
    RingNode *head = new RingNode();
    //read_recursively create RingNode
    size = read_recursively (file, current,head,size);
    return size;
}//read_Input



void delete_RingNode(RingNode*& head, int size){
    cout << "RingNode origianl size : "<<size <<endl;
    int delete_num = 0;
    for (int i=0; i<size; i++) {
        if ( head->next !=NULL ){
            RingNode *current = head;
            head = head->next;
            free( current );
            delete_num++;
        }//if
        else{
            free(head);
            delete_num++;
        }//else
    }//for
    cout << "delete_RingNode size : "<<delete_num <<endl;
  
}//delete_RingNode

int main (int argc, char *argv[]) {
    RingNode* start_point = NULL;
    
    int size = read_Input_to_RingNode(argv[1], start_point);
    print_the_ring(start_point, size);
    delete_RingNode(start_point, size);
    return 0;
}//main()