#include <iostream>
#include "bigint.h"
using namespace std;

bool bigint::operator ==(const bigint &rs)const{
    return s == rs.s;
}//==

bool bigint::operator !=(const bigint &rs)const{
    return s != rs.s;
}//!=

bool bigint::operator >=(const bigint &rs)const{
    return s >= rs.s;
}//>=

bool bigint::operator <=(const bigint &rs)const{
    return s <= rs.s;
}//<=

bool bigint::operator >(const bigint &rs)const{
    return s > rs.s;
}//>

bool bigint::operator <(const bigint &rs)const{
    return s < rs.s;
}//<