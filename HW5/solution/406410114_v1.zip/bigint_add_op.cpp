#include <iostream>
#include "bigint.h"
using namespace std;
bigint bigint:: operator +(const bigint &rs){
    //cout << "add start\n";
    int sum[45],carry = 0;
    int len1 = s.length();
    int len2 = rs.s.length();
    int max_len = max( len1,len2 );
    //cout <<"max_len:" << max_len<<endl;
    bigint left;
    left.s = s;
    for (int i = 0; i<5;i++)
        left.A[i] = A[i];
    bigint right = rs;
    
    //smaller number add zero 
    for( int i = len1;i<max_len;i++ )
        left.s = "0"+left.s;
    for( int i = len2;i<max_len;i++ )
        right.s = "0"+right.s;
    
    for( int i = max_len-1; i >=0 ;i-- ){
        //cout << "i:"<<i<<endl;
        int num =(left.s[i]-'0') + ( right.s[i]-'0' ) +carry;
        sum[max_len-i-1] = num %10;
        carry = num/10;
    }//for
    

    if ( max_len <=45 )
      sum[max_len] = carry;
    
    
    string new_s;
    if ( carry >0 )
        new_s = to_string( carry );
        
    for( int i = max_len-1; i >=0&& i<45 ;i-- ){
        new_s = new_s + to_string(sum[i]); 
    }//for
    
    
    
    int new_len = new_s.length();
    if ( new_len <=9 ){
      left.A[0] = stoi(new_s);
      left.A[1] = 0;
      left.A[2] = 0;
      left.A[3] = 0;
      left.A[4] = 0;
    }//if
    else if ( new_len >9 &&new_len <=18   ){
      left.A[0] = stoi(new_s.substr( new_len-8,9 ));
      left.A[1] = stoi(new_s.substr( 0,new_len-9 ));
      left.A[2] = 0;
      left.A[3] = 0;
      left.A[4] = 0;
    }//if
    else if ( new_len >18 &&new_len <=27   ){
      left.A[0] = stoi(new_s.substr( new_len-8,9 ));
      left.A[1] = stoi(new_s.substr( new_len-17,9 ));
      left.A[2] = stoi(new_s.substr( 0,new_len-18 ));
      left.A[3] = 0;
      left.A[4] = 0;
    }//if
    else if ( new_len >27 &&new_len <=36   ){
      left.A[0] = stoi(new_s.substr( new_len-8,9 ));
      left.A[1] = stoi(new_s.substr( new_len-17,9 ));
      left.A[2] = stoi(new_s.substr( new_len-26,9 ));
      left.A[3] = stoi(new_s.substr( 0,new_len-27 ));
      left.A[4] = 0;
    }//if
    else if ( new_len >36 &&new_len <=45   ){
      left.A[0] = stoi(new_s.substr( new_len-8,9 ));
      left.A[1] = stoi(new_s.substr( new_len-17,9 ));
      left.A[2] = stoi(new_s.substr( new_len-26,9 ));
      left.A[3] = stoi(new_s.substr( new_len-35,9 ));
      left.A[4] = stoi(new_s.substr( 0,new_len-36 ));
    }//if
    
    
    bigint res;
    res.s = new_s;
    for ( int i = 0;i<5;i++ )
      res.A[i] = left.A[i];
    
    return res;      
}//+