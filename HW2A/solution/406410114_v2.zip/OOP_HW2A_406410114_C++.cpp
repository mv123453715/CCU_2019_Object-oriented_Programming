//#include <iostream>
//#include <stdio.h>
//#include <string.h>
#include <bits/stdc++.h>
using namespace std;

void ReadList ( char filename[],int A[],int &n );
void Avgs( int A[] ,float &avg_all,float &avg_pos,float &avg_nega,int &n);
int Large( int A[] ,int &n);
void Display( int A[],int &n,float avg_all,float avg_pos,float avg_nega,float large_num);


int main (int argc, char *argv[]) {
    int A[100],i,n = 0;
    float avg_all,avg_pos,avg_nega,large_num;
    
    if ( argv[1] == NULL ){
        cout << "Error! please enter ./a.out + \"FILENAME\"\n";
        exit(0);
    }//if
    
    //fgets read input into A
    ReadList( argv[1],A,n );   
    //compute Average of interger ,Average of positive integer,Average of negative integer
    Avgs( A ,avg_all,avg_pos,avg_nega,n);
    //find Large of interger
    large_num = Large( A,n);
    //Display Average of interger ,Average of positive integer,Average of negative integer,Large of interger
    Display( A,n,avg_all,avg_pos,avg_nega,large_num);
    
    return 0;
}//main()

void ReadList ( char filename[],int A[],int &n ){
     //open file 
     FILE * fd;
     fd = fopen (filename , "r");
     char str[1000];
     char *token ;
     const char *s = " ";
     int i ;
     
     //fgets get string 
     if (fd == NULL) {
         cout << "Error! opening file isn't exist!\n";
         exit(0);
     }//if
     else {
         if ( fgets (str , 1000 , fd) != NULL ){
         /* walk through tokens */                        
             token = strtok(str, s);
             while( token != NULL ) {
                A[n++] = atoi(token);
                token = strtok(NULL, s);
            }//while
         }//if
         fclose (fd);
     }//else
}//ReadList

void Avgs( int A[] ,float &avg_all,float &avg_pos,float &avg_nega,int &n){
    int i = 0,pos_count = 0,nega_count = 0;
    
    //compute total,total_pos,total_nega
    for ( i = 0;i<n;i++){
        avg_all = avg_all + A[i];
        if ( A[i] > 0 ){
            pos_count++;
            avg_pos = avg_pos + A[i];
        }//if
        else if ( A[i] < 0  ){
            nega_count++;
            avg_nega = avg_nega + A[i];        
        }//else if 
    }//for
    
    //compute avg_all,avg_pos,avg_nega
    avg_all /=float(n);
    avg_pos /=float(pos_count);
    avg_nega/=float(nega_count);


}//Avgs



int Large( int A[],int &n ){
    int Large_num,i;
    Large_num = A[0];
    
    //find Large num
    for (i = 1; i<n;i++){
        if ( A[i] >Large_num )
            Large_num = A[i];
    }//for
    return Large_num;
}//Large


void Display( int A[],int &n,float avg_all,float avg_pos,float avg_nega,float large_num){
    int i;
    cout << "A array : ";
    for ( i = 0 ; i<n;i++ )
        cout << A[i] << " ";
    cout << endl;
    cout<< "Average of interger        :" << avg_all<<endl;
    cout<< "Average of positive integer:" << avg_pos<<endl;
    cout<< "Average of negative integer:" << avg_nega<<endl;
    cout<< "Large   of interger        :" << large_num<<endl;
}//display



